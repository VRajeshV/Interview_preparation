#!/usr/bin/env bash

ls -lrt | grep -E "^d"
