#include<stdio.h>
#include <stdlib.h>

int main()
{
	while(1)
	{
		printf("%d\n", rand());
		getchar();
	}
	return 0;
}
