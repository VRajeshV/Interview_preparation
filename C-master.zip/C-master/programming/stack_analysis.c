#include<stdio.h>

int give_val(int var)
{
	return var;
}

int main()
{
	printf("%d\n", give_val(10));
	return 0;
}
